<meta name=”robots” content=”noindex, nofollow”>

Internet Archive ROM Launcher
==========================

![IARL](https://github.com/zach-morris/plugin.program.iarl/blob/master/fanart.jpg)

Play retro games from the cloud!

The Internet Archive ROM Launcher (IARL) will launch Games from the cloud using [Kodi](http://kodi.tv)



Installation
-------------

- Download my repository zipfile from [here](https://goo.gl/AdQoNt) to install the addon and get automatic updates.

or

- Download the latest version zipfile from [here](https://goo.gl/ylg2rJ) to install by zipfile.



Help
-------------

See the [wiki](https://github.com/zach-morris/plugin.program.iarl/wiki)



IARL in Action
-------------------
[![IARL](https://github.com/zach-morris/iarl.media/raw/master/support/IARL_Slideshow.gif)](https://www.youtube.com/watch?v=fJ6nuyM6sOo)



Support
-------------------

Support the internet archive by [donating](https://archive.org/donate/)!
