from util import update_addonxml

update_addonxml('executable game')